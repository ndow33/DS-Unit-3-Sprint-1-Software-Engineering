from random import randint, uniform  # sample, uniform
from acme import Product

ADJECTIVES = ['Awesome', 'Shiny', 'Impressive', 'Portable', 'Improved']
NOUNS = ['Anvil', 'Catapult', 'Disguise', 'Mousetrap', '???']


def generate_products(num_products=30):

    products = ["Product"] * num_products

    for x in range(num_products):
        # Generate a name
        adjective = ADJECTIVES[randint(0, 4)]
        noun = NOUNS[randint(0, 4)]
        name = adjective + ' ' + noun
        # Generate a price and weight
        price = randint(5, 100)
        weight = randint(5, 100)
        # generate flammability
        flammability = uniform(0, 2.5)
        # Create a product with these attributes
        prod = Product(name)
        prod.price = price
        prod.weight = weight
        prod.flammability = flammability
        # Add the product object to a list
        products[x] = prod
    return print(products)


def inventory_report(products):
    print("ACME CORPORATION OFFICIAL INVENTORY REPORT")
    print("Unique product names: ", len(products))
    print("Average Price: ")


if __name__ == '__main__':
    generate_products()


'''$ python acme_report.py
ACME CORPORATION OFFICIAL INVENTORY REPORT
Unique product names: 19
Average price: 56.8
Average weight: 54.166666666666664
Average flammability: 1.258097155966675'''

# inventory_report(
