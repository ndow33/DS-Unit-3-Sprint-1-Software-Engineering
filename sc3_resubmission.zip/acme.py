from random import randint


class Product():
    def __init__(self, name):
        '''
        Initializes a new "Product" object
        '''
        self.name = name
        self.price = 10
        self.weight = 20
        self.flammability = .5
        self.identifier = randint

    def stealability(self):
        '''
        calculates the price divided by the weight, and then
        returns a message: if the ratio is less than 0.5 return
        "Not so stealable...",
        if it is greater or equal to 0.5 but less than 1.0 return
        "Kinda stealable.",
        and otherwise return "Very stealable!"
        '''
        ratio = self.price / self.weight
        if(ratio < .5):
            print("Not so stealable...")
        if((ratio >= .5) & (ratio < 1.0)):
            print("Kinda stealable.")
        if(ratio >= 1.0):
            print("Very stealable!")

    def explode(self):
        '''
        calculates the flammability times the weight, and then
        returns a message: if the product is less than 10 return "...fizzle.",
        if it is greater or equal to 10 but less than 50 return "...boom!",
        and otherwise return "...BABOOM!!"
        '''
        explosive = self.flammability * self.weight
        if(explosive < 10):
            print("...fizzle.")
        if((explosive >= 10) & (explosive < 50)):
            print("...boom!")
        if(explosive >= 50):
            print("...BABOOM!!")


class BoxingGlove(Product):
    '''
    Initializes a new BoxingGlove object
    Change the default `weight` to 10 (but leave other defaults unchanged)
    '''
    def __init__(self, name):
        super().__init__(name)
        self.weight = 10

    def explode(self):
        print("...it's a glove.")

    def punch(self):
        if (self.weight < 5):
            print("That tickles.")
        if ((self.weight >= 5) & (self.weight < 15)):
            print("Hey that hurt!")
        if (self.weight >= 15):
            print("OUCH!")
