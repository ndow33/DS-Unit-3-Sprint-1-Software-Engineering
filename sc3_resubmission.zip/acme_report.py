from random import randint, sample, uniform
from acme import Product
import pandas as pd

# Useful to use with random.sample to generate names
ADJECTIVES = ['Awesome', 'Shiny', 'Impressive', 'Portable', 'Improved']
NOUNS = ['Anvil', 'Catapult', 'Disguise', 'Mousetrap', '???']


def generate_products(num_products=30):
    # create an empty list
    products = []
    for x in range(num_products):
        # add product objects to that list using a for loop
        # take an adjective and a noun and combine them to 
        # make a unique name
        adjective = sample(ADJECTIVES, 1) 
        noun = sample(NOUNS, 1)
        name = adjective[0] + ' ' + noun[0]
        # instantiate a new product object
        prod = Product(name)
        # print(prod.name)
        # set the product weight to a randomint between 5 & 100
        prod.weight = randint(5, 100)
        # print(prod.weight)
        # set the product flammability to a random float between 0 and 2.5
        prod.flammability = uniform(0, 2.5)
        # print(prod.flammability)
        # set the product price to a randomint between 5 and 10
        prod.price = randint(5, 100)
        # print(prod.price)
        # append the list with the new product object
        products.append(prod)
        # print(len(products))
    return products

def inventory_report(products):
    # instantiate lists to hold values of products
    names = []
    prices = []
    weights = []
    flames = []
    # write a for loop that will extract information from products[]
    for x in range(len(products)):
        names.append(products[x].name)
        prices.append(products[x].price)
        weights.append(products[x].weight)
        flames.append(products[x].flammability)
    # cast the lists as pandas series for computing
    names = pd.Series(names)
    prices = pd.Series(prices)
    weights = pd.Series(weights)
    flames = pd.Series(flames)
    # compute the desired otuputs
    unique_names = names.nunique()
    avg_price = prices.mean()
    avg_weight = weights.mean()
    avg_flam = flames.mean()
    # report the desired outputs
    print('ACME CORPORATION OFFICIAL INVENTORY REPORT')
    print('Unique product names: ', unique_names)
    print('Average price: ', avg_price)
    print('Average weight: ', avg_weight)
    print('Average flammability: ', avg_flam)


if __name__ == '__main__':
    inventory_report(generate_products())


'''$ python acme_report.py
ACME CORPORATION OFFICIAL INVENTORY REPORT
Unique product names: 19
Average price: 56.8
Average weight: 54.166666666666664
Average flammability: 1.258097155966675'''

# inventory_report(
